#ifndef _REG_OPENCLINFO_H
#define _REG_OPENCLINFO_H

#include <iostream>
#include "InfoDevice.h"

void showCLInfo(void);

#endif
